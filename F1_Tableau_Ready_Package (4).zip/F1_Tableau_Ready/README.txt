F1 RACE INTELLIGENCE - TABLEAU READY DATA PACKAGE

CONTENTS
- processed/: five cleaned CSV files for Tableau
- F1_Data_Audit_Report.xlsx: multi-sheet audit workbook
- dataset_audit_summary.csv: row/column/missing/duplicate summary
- missing_values_report.csv: column-level missing-value report
- data_quality_issues.csv: issues flagged and treatment notes
- relationship_key_audit.csv: circuit_id match audit

CLEANING APPLIED
1. Trimmed leading/trailing whitespace in text columns.
2. Converted empty text strings to missing values.
3. Parsed race_results.race_date to ISO date format (YYYY-MM-DD).
4. Added race_results helper fields:
   - dnf_count
   - race_driver_occurrence_count
   - duplicate_race_driver_flag
   - race_driver_team_conflict_flag
5. Added qualifying_results helper flags:
   - placeholder_driver_flag
   - placeholder_team_flag

IMPORTANT DATA GOVERNANCE NOTES
- No source rows were deleted.
- No missing analytical values were blindly replaced with zero.
- DNF rows were retained.
- Repeated race_id + driver records were flagged, not deleted, because
  they are not exact duplicate rows and the team differs in affected groups.
- Placeholder Driver_n / Team_n values were flagged, not fabricated/replaced.
- This package is cleaned for Tableau ingestion, but flagged source-data
  quality issues still require disclosure/handling in analysis.
- The source appears synthetic/modified in places; do not claim it is
  fully verified official historical F1 data without independent validation.

TABLEAU NOTE
Connect the five CSVs from processed/ as separate logical tables.
Before creating relationships, verify the intended grain and keys.
Do not physically join all fact tables together; this can multiply rows.
